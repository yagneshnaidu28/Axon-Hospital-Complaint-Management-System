# Student-forms
In this project any student can add personal data and he can update and delete data. I made this project using Html, css and JavaScript.
